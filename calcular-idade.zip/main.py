from flask import Flask,request,render_template
from datetime import datetime
app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/calcular_idade',methods=['POST'])
def cacular_idade():
    try:
        ano_atual = datetime.now().year
        nascimento = int(request.form['nascimento'])
        calculo = (ano_atual - nascimento)
        return render_template('index.html',calculo=calculo)

    except Exception as e:
        calculo = f'erro {e}'
        return render_template('index.html', calculo=calculo)



if __name__=='__main__':
    app.run(debug=True)